/* 
CHALLENGE 3
Change code to match output.
*/

"use strict";

var i = 10;

for (var i = 0; i < 5; i++) {
// some stuff
    console.log(i);
}
console.log(i);
// It currently prints: 5
// We want it to stay: 10
